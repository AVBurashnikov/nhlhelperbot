from api_models.player import Player
from api_models.stats import Stats


class PlayerExtended(Player, Stats):
    ...
